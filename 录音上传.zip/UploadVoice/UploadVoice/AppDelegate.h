//
//  AppDelegate.h
//  UploadVoice
//
//  Created by bean on 15/12/24.
//  Copyright © 2015年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

