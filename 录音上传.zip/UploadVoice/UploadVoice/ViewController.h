//
//  ViewController.h
//  UploadVoice
//
//  Created by bean on 15/12/24.
//  Copyright © 2015年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

